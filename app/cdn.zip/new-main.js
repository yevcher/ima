'use strict';

ima.controller('MainCtrl', function($scope, $location) {
	switch ($location.path()) {
		case '/':
			$scope.ima-page-title = "Main Page. Yes!";
			break;
		case '/1':
			$scope.ima-page-title = "Page One. Yes!";
			break;
		case '/2':
			$scope.ima-page-title = "Page Two. Yes!";
			break;
		default:
			$scope.ima-page-title = "Just IMA Page";
	}